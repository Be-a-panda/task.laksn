<?php

  $receiving_email_address = 'studyybuddyyyy@gmail.com';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer-master/src/Exception.php';
require 'PHPMailer-master/src/PHPMailer.php';
require 'PHPMailer-master/src/SMTP.php';



$mail = new PHPMailer(true);
$mail->IsSMTP();
$mail->Mailer = "smtp";

  try {
    // $mail->SMTPDebug = 1;
    $mail->SMTPAuth = TRUE;
    $mail->SMTPSecure = "tls";
    $mail->Host       = 'smtp.gmail.com';
    $mail->Username   = 'studyybuddyyyy@gmail.com';
    $mail->Password   = 'StudyBuddy@1429';
    $mail->Port       = 587;

    $mail->IsHTML(true);
    $mail->AddAddress($receiving_email_address, "recevier");
    $mail->SetFrom("studyybuddyyyy@gmail.com", "sender");
    $mail->Subject = "Contact Form";
    $content = "<b>From: </b>".$_POST['name']."<br><b>Email: </b>".$_POST['email']."<br><b>Message: <b>".$_POST['message'];
    $mail->MsgHTML($content);
    if($mail->send()) {
      echo "OK";
    }
  } catch (Exception $e) {
    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
  }

?>
